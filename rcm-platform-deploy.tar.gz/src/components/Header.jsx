import React, { useState } from 'react';
import { Search, Menu, Bell, Settings, RefreshCw } from 'lucide-react';

const Header = ({ toggleSidebar }) => {
    const [isSyncing, setIsSyncing] = useState(true);

    return (
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 sticky top-0 z-40 shadow-sm">
            <div className="flex items-center gap-4">
                <button onClick={toggleSidebar} className="lg:hidden p-2 hover:bg-gray-100 rounded-md">
                    <Menu className="w-5 h-5 text-gray-600" />
                </button>

                <div className="relative w-96 hidden md:block">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Search claims, patients, payors..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary)]/50 focus:border-[var(--primary)] transition-all bg-gray-50/50 focus:bg-white"
                    />
                </div>
            </div>

            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-medium border border-emerald-100">
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>Cubhub Sync Active</span>
                </div>

                <span className="text-xs text-gray-500 hidden sm:block">Last sync: 2 min ago</span>

                <div className="h-8 w-[1px] bg-gray-200 mx-2"></div>

                <button className="p-2 text-gray-500 hover:text-[var(--primary)] hover:bg-gray-50 rounded-full transition-colors relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-1.5 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
                </button>

                <button className="p-2 text-gray-500 hover:text-[var(--primary)] hover:bg-gray-50 rounded-full transition-colors">
                    <Settings className="w-5 h-5" />
                </button>

                <div className="ml-2 w-8 h-8 rounded-full bg-gradient-to-tr from-[var(--primary)] to-[var(--primary-dark)] text-white flex items-center justify-center font-bold text-xs ring-2 ring-offset-2 ring-transparent hover:ring-[var(--primary)]/20 transition-all cursor-pointer">
                    JD
                </div>
            </div>
        </header>
    );
};

export default Header;
